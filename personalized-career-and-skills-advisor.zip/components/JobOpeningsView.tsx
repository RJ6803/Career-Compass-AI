import React, { useState, useEffect, useCallback } from 'react';
import { CareerPath, UserProfile, JobOpening, GroundingSource } from '../types';
import { getJobOpenings } from '../services/geminiService';
import { LoadingSpinner } from './LoadingSpinner';

interface JobOpeningsViewProps {
  careerPath: CareerPath;
  userProfile: UserProfile;
}

const JobCard: React.FC<{ job: JobOpening }> = ({ job }) => (
    <div className="bg-base-300 p-6 rounded-xl border border-base-300 transition-all duration-300 hover:border-brand-secondary hover:shadow-lg">
        <div className="flex justify-between items-start mb-2">
            <div>
                <h3 className="text-xl font-bold text-text-primary">{job.title}</h3>
                <p className="text-text-secondary">{job.company} - {job.location}</p>
            </div>
            <div className="text-sm font-bold bg-brand-accent text-base-100 px-3 py-1 rounded-full">
                {job.matchScore}% Match
            </div>
        </div>
        <p className="text-text-secondary my-4">{job.description}</p>
        <a href={job.url} target="_blank" rel="noopener noreferrer" className="inline-block bg-brand-secondary hover:bg-brand-primary text-white font-bold py-2 px-4 rounded-lg transition-colors duration-300">
            Apply Now ↗
        </a>
    </div>
);

const JobOpeningsView: React.FC<JobOpeningsViewProps> = ({ careerPath, userProfile }) => {
  const [openings, setOpenings] = useState<JobOpening[]>([]);
  const [sources, setSources] = useState<GroundingSource[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [country, setCountry] = useState<'USA' | 'India'>('USA');
  const [jobType, setJobType] = useState<'Entry-Level' | 'Internship' | 'Remote' | 'Part-time'>('Entry-Level');

  const jobTypes: typeof jobType[] = ['Entry-Level', 'Internship', 'Remote', 'Part-time'];

  const fetchOpenings = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await getJobOpenings(careerPath.title, userProfile, country, jobType);
      setOpenings(result.openings);
      setSources(result.sources);
    } catch (err) {
      console.error("Failed to get job openings:", err);
      setError("Could not fetch job openings. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [careerPath, userProfile, country, jobType]);

  useEffect(() => {
    fetchOpenings();
  }, [fetchOpenings]);
  
  if (isLoading) {
    return <div className="flex flex-col items-center justify-center h-full">
        <LoadingSpinner />
        <p className="mt-4 text-lg">Searching for relevant job openings...</p>
    </div>;
  }

  if (error) {
    return <div className="text-center text-red-400">{error}</div>;
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-bold mb-2">Job Openings: <span className="text-brand-accent">{careerPath.title}</span></h1>
        <p className="text-text-secondary text-lg">{jobType} opportunities in {country === 'USA' ? 'the United States' : 'India'} based on your profile.</p>
        
        <div className="mt-6 flex flex-col sm:flex-row gap-6">
          <div>
            <label className="block text-sm font-medium text-text-secondary mb-2">Country</label>
            <div className="flex items-center space-x-2 bg-base-300 p-1 rounded-lg w-min">
              <button
                onClick={() => setCountry('USA')}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${country === 'USA' ? 'bg-brand-secondary text-white' : 'text-text-secondary hover:bg-base-200'}`}
              >
                USA
              </button>
              <button
                onClick={() => setCountry('India')}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${country === 'India' ? 'bg-brand-secondary text-white' : 'text-text-secondary hover:bg-base-200'}`}
              >
                India
              </button>
            </div>
          </div>
        
          <div>
             <label className="block text-sm font-medium text-text-secondary mb-2">Job Type</label>
            <div className="flex items-center space-x-2 bg-base-300 p-1 rounded-lg flex-wrap gap-y-1">
              {jobTypes.map(type => (
                <button
                  key={type}
                  onClick={() => setJobType(type)}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${jobType === type ? 'bg-brand-secondary text-white' : 'text-text-secondary hover:bg-base-200'}`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>


      <div className="space-y-4">
        {openings.length > 0 ? (
          openings.map((job, index) => <JobCard key={index} job={job} />)
        ) : (
          <p className="text-center text-text-secondary">No job openings found with the current filters. Try a different search or check back later.</p>
        )}
      </div>

       {sources.length > 0 && (
          <div className="mt-8">
              <h2 className="text-2xl font-semibold mb-4">Sources</h2>
              <div className="bg-base-300 p-6 rounded-xl space-y-3">
                {sources.map((source, index) => (
                    source.web && <a href={source.web.uri} key={index} target="_blank" rel="noopener noreferrer" className="block p-3 bg-base-200 rounded-lg hover:bg-base-100 transition-colors">
                        <p className="font-semibold text-brand-secondary">{source.web.title}</p>
                        <p className="text-xs text-text-secondary truncate">{source.web.uri}</p>
                    </a>
                ))}
              </div>
          </div>
      )}
    </div>
  );
};

export default JobOpeningsView;