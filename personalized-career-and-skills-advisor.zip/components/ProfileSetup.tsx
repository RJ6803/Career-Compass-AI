import React, { useState, useEffect } from 'react';
import { UserProfile } from '../types';

interface ProfileSetupProps {
  onSubmit: (profile: UserProfile) => void;
  error: string | null;
  initialName?: string;
}

const Chip: React.FC<{ text: string; onRemove: () => void }> = ({ text, onRemove }) => (
  <div className="flex items-center bg-brand-secondary text-white text-sm font-medium px-3 py-1 rounded-full">
    <span>{text}</span>
    <button onClick={onRemove} className="ml-2 text-white hover:text-brand-light focus:outline-none">
      &times;
    </button>
  </div>
);

const ProfileSetup: React.FC<ProfileSetupProps> = ({ onSubmit, error, initialName }) => {
  const [name, setName] = useState(initialName || '');
  const [education, setEducation] = useState('');
  const [skills, setSkills] = useState<string[]>([]);
  const [interests, setInterests] = useState<string[]>([]);
  const [currentSkill, setCurrentSkill] = useState('');
  const [currentInterest, setCurrentInterest] = useState('');

  useEffect(() => {
    if (initialName) {
      setName(initialName);
    }
  }, [initialName]);

  const handleAddChip = (
    value: string,
    setValue: React.Dispatch<React.SetStateAction<string>>,
    setList: React.Dispatch<React.SetStateAction<string[]>>
  ) => {
    if (value.trim() && !setList.toString().includes(value.trim())) {
      setList(prev => [...prev, value.trim()]);
    }
    setValue('');
  };

  const handleKeyDown = (
    e: React.KeyboardEvent<HTMLInputElement>,
    value: string,
    setValue: React.Dispatch<React.SetStateAction<string>>,
    setList: React.Dispatch<React.SetStateAction<string[]>>
  ) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      handleAddChip(value, setValue, setList);
    }
  };
  
  const removeChip = (index: number, setList: React.Dispatch<React.SetStateAction<string[]>>) => {
    setList(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && education && interests.length > 0) {
      onSubmit({ 
        name, 
        education, 
        skills, 
        interests, 
        coins: 0, 
        dailyStreak: 0, 
        lastQuizDate: '',
        email: '',
        phone: '',
        github: '',
        roadmapDurations: {},
        resumeUrl: '',
        theme: 'default',
      });
    }
  };

  return (
    <div className="min-h-screen bg-base-100 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-base-200 rounded-2xl shadow-2xl p-8 border border-base-300">
        <h1 className="text-3xl font-bold text-center mb-2 text-brand-accent">Welcome to Career Compass AI</h1>
        <p className="text-center text-text-secondary mb-8">Let's build your personalized career roadmap.</p>
        
        {error && <div className="bg-red-900 border border-red-700 text-red-200 px-4 py-3 rounded-lg relative mb-6" role="alert">
          <strong className="font-bold">Oops! </strong>
          <span className="block sm:inline">{error}</span>
        </div>}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-text-secondary mb-2">Full Name</label>
            <input type="text" id="name" value={name} onChange={e => setName(e.target.value)} className="w-full bg-base-300 border border-base-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-brand-secondary focus:outline-none" placeholder="e.g., Ada Lovelace" required />
          </div>
          <div>
            <label htmlFor="education" className="block text-sm font-medium text-text-secondary mb-2">Highest Education / Field of Study</label>
            <input type="text" id="education" value={education} onChange={e => setEducation(e.target.value)} className="w-full bg-base-300 border border-base-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-brand-secondary focus:outline-none" placeholder="e.g., B.S. in Computer Science" required />
          </div>
          
          <div>
            <label htmlFor="skills" className="block text-sm font-medium text-text-secondary mb-2">Your Skills (Optional)</label>
            <div className="flex flex-wrap gap-2 p-2 bg-base-300 border border-base-300 rounded-lg">
              {skills.map((skill, i) => <Chip key={i} text={skill} onRemove={() => removeChip(i, setSkills)} />)}
              <input type="text" id="skills" value={currentSkill} onChange={e => setCurrentSkill(e.target.value)} onKeyDown={e => handleKeyDown(e, currentSkill, setCurrentSkill, setSkills)} className="flex-grow bg-transparent focus:outline-none p-1" placeholder="Add a skill..." />
            </div>
          </div>

          <div>
            <label htmlFor="interests" className="block text-sm font-medium text-text-secondary mb-2">Your Interests (add with Enter or comma)</label>
            <div className="flex flex-wrap gap-2 p-2 bg-base-300 border border-base-300 rounded-lg">
              {interests.map((interest, i) => <Chip key={i} text={interest} onRemove={() => removeChip(i, setInterests)} />)}
              <input type="text" id="interests" value={currentInterest} onChange={e => setCurrentInterest(e.target.value)} onKeyDown={e => handleKeyDown(e, currentInterest, setCurrentInterest, setInterests)} className="flex-grow bg-transparent focus:outline-none p-1" placeholder="Add an interest..." />
            </div>
          </div>

          <button type="submit" className="w-full bg-brand-secondary hover:bg-brand-primary text-white font-bold py-3 px-4 rounded-lg transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-base-200 focus:ring-brand-secondary">
            Generate My Career Path
          </button>
        </form>
      </div>
    </div>
  );
};

export default ProfileSetup;