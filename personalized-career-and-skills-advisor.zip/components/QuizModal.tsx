import React, { useState } from 'react';
import { QuizQuestion, QuizDifficulty } from '../types';
import { getQuizForSkill } from '../services/geminiService';
import { LoadingSpinner } from './LoadingSpinner';

interface QuizModalProps {
  skill: string;
  onClose: () => void;
  onQuizComplete: (reward: number) => void;
}

const QuizModal: React.FC<QuizModalProps> = ({ skill, onClose, onQuizComplete }) => {
  const [quizState, setQuizState] = useState<'options' | 'loading' | 'active' | 'finished'>('options');
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [rewardClaimed, setRewardClaimed] = useState(false);

  // Quiz options state
  const [difficulty, setDifficulty] = useState<QuizDifficulty>('Medium');
  const [numQuestions, setNumQuestions] = useState<number>(5);

  const getRewardAmount = (level: QuizDifficulty): number => {
    switch (level) {
      case 'Easy': return 15;
      case 'Medium': return 30;
      case 'Hard': return 45;
      default: return 30;
    }
  };

  const handleStartQuiz = async () => {
    setQuizState('loading');
    setError(null);
    try {
      const quizData = await getQuizForSkill(skill, difficulty, numQuestions);
      if (quizData && quizData.length > 0) {
        setQuestions(quizData);
        setQuizState('active');
      } else {
        setError("Couldn't generate a quiz for this topic. Please try again later.");
        setQuizState('options');
      }
    } catch (err) {
      console.error("Failed to fetch quiz:", err);
      setError("An error occurred while creating your quiz.");
      setQuizState('options');
    }
  };

  const resetQuiz = () => {
    setQuestions([]);
    setCurrentQuestionIndex(0);
    setSelectedAnswer(null);
    setIsAnswered(false);
    setScore(0);
    setQuizState('options');
    setError(null);
    setRewardClaimed(false);
  };

  const handleAnswerSubmit = () => {
    if (selectedAnswer === null) return;

    setIsAnswered(true);
    if (selectedAnswer === questions[currentQuestionIndex].correctAnswerIndex) {
      setScore(prev => prev + 1);
    }

    setTimeout(() => {
      if (currentQuestionIndex < questions.length - 1) {
        setCurrentQuestionIndex(prev => prev + 1);
        setSelectedAnswer(null);
        setIsAnswered(false);
      } else {
        setQuizState('finished');
      }
    }, 1500);
  };

  const handleClaimReward = () => {
    if (rewardClaimed) return;
    const reward = getRewardAmount(difficulty);
    onQuizComplete(reward);
    setRewardClaimed(true);
  };

  const passingScore = questions.length > 0 ? Math.ceil(questions.length * 0.66) : 1;
  const passed = score >= passingScore;

  const renderContent = () => {
    if (quizState === 'loading') {
      return (
        <div className="flex flex-col items-center justify-center h-64">
          <LoadingSpinner />
          <p className="mt-4 text-text-secondary">Generating your {difficulty} quiz...</p>
        </div>
      );
    }

    if (quizState === 'options') {
      const rewardAmount = getRewardAmount(difficulty);
      return (
        <div className="p-8">
          <h3 className="text-2xl font-semibold text-center mb-6">Quiz Options</h3>
          
          <div className="bg-base-200 p-4 rounded-lg mb-6 border border-base-100">
              <div className="flex justify-center items-center mb-2">
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-brand-accent mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                <h4 className="font-bold text-lg text-brand-accent">Before you begin:</h4>
              </div>
              <ul className="text-text-secondary space-y-1 text-sm text-center">
                  <li>This quiz will test your knowledge of <span className="font-bold text-text-primary">{skill}</span>.</li>
                  <li>You must score <span className="font-bold text-text-primary">66% or higher</span> to pass.</li>
                  <li>A successful attempt rewards you with <span className="font-bold text-yellow-400">{rewardAmount} coins 💰</span>.</li>
              </ul>
          </div>

          {error && (
            <div className="bg-red-900 border border-red-700 text-red-200 px-4 py-3 rounded-lg text-center mb-6" role="alert">
              {error}
            </div>
          )}

          <div className="mb-6 text-center">
            <label className="block text-sm font-medium text-text-secondary mb-2">Difficulty</label>
            <div className="inline-flex space-x-1 bg-base-200 p-1 rounded-lg">
              {(['Easy', 'Medium', 'Hard'] as QuizDifficulty[]).map(d => (
                <button
                  key={d}
                  onClick={() => setDifficulty(d)}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${difficulty === d ? 'bg-brand-secondary text-white' : 'text-text-secondary hover:bg-base-100'}`}
                >
                  {d}
                </button>
              ))}
            </div>
          </div>

          <div className="mb-8 text-center">
            <label className="block text-sm font-medium text-text-secondary mb-2">Number of Questions</label>
            <div className="inline-flex space-x-1 bg-base-200 p-1 rounded-lg">
              {[5, 10, 15].map(n => (
                <button
                  key={n}
                  onClick={() => setNumQuestions(n)}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${numQuestions === n ? 'bg-brand-secondary text-white' : 'text-text-secondary hover:bg-base-100'}`}
                >
                  {n} Questions
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={handleStartQuiz}
            className="w-full bg-brand-accent hover:bg-teal-500 text-base-100 font-bold py-3 px-4 rounded-lg transition-colors duration-300"
          >
            Start Quiz
          </button>
        </div>
      );
    }

    if (quizState === 'finished') {
      const rewardAmount = getRewardAmount(difficulty);
      return (
        <div className="text-center p-8">
          <h2 className="text-3xl font-bold mb-4">Quiz Complete!</h2>
          <p className="text-lg text-text-secondary mb-2">You scored:</p>
          <p className={`text-5xl font-bold mb-6 ${passed ? 'text-brand-accent' : 'text-red-500'}`}>{score} / {questions.length}</p>
          {passed ? (
            <>
              <p className="text-green-400 mb-4">Congratulations! You've passed the quiz.</p>
              <button
                onClick={handleClaimReward}
                disabled={rewardClaimed}
                className="bg-yellow-400 hover:bg-yellow-500 text-base-100 font-bold py-3 px-6 rounded-lg transition-colors duration-300 disabled:bg-yellow-700 disabled:cursor-not-allowed"
              >
                {rewardClaimed ? '💰 Reward Claimed!' : `Claim ${rewardAmount} Coins 💰`}
              </button>
            </>
          ) : (
            <p className="text-yellow-400 mb-4">Good effort! Review the material and try again to earn a reward.</p>
          )}
          <div className="flex justify-center space-x-4 mt-6">
            <button onClick={resetQuiz} className="bg-base-200 hover:bg-base-100 text-text-primary font-bold py-2 px-6 rounded-lg transition-colors">
              Try Again
            </button>
            <button onClick={onClose} className="bg-brand-secondary hover:bg-brand-primary text-white font-bold py-2 px-6 rounded-lg transition-colors">
              Close
            </button>
          </div>
        </div>
      );
    }

    if (quizState === 'active' && questions.length > 0) {
      const currentQuestion = questions[currentQuestionIndex];
      return (
        <div className="p-8">
          <p className="text-sm text-text-secondary mb-2">Question {currentQuestionIndex + 1} of {questions.length}</p>
          <h3 className="text-2xl font-semibold mb-6">{currentQuestion.question}</h3>
          <div className="space-y-3">
            {currentQuestion.options.map((option, index) => {
              const isCorrect = index === currentQuestion.correctAnswerIndex;
              let buttonClass = 'bg-base-200 hover:bg-base-100 border-base-100';
              if (isAnswered) {
                if (isCorrect) {
                  buttonClass = 'bg-green-800 border-green-600';
                } else if (selectedAnswer === index) {
                  buttonClass = 'bg-red-800 border-red-600';
                }
              } else if (selectedAnswer === index) {
                buttonClass = 'bg-brand-secondary border-brand-primary';
              }
              return (
                <button
                  key={index}
                  onClick={() => !isAnswered && setSelectedAnswer(index)}
                  className={`w-full text-left p-4 rounded-lg border-2 transition-colors duration-200 ${buttonClass}`}
                  disabled={isAnswered}
                >
                  {option}
                </button>
              );
            })}
          </div>
          <button
            onClick={handleAnswerSubmit}
            disabled={selectedAnswer === null || isAnswered}
            className="w-full mt-8 bg-brand-accent hover:bg-teal-500 text-base-100 font-bold py-3 px-4 rounded-lg transition-colors duration-300 disabled:bg-base-100 disabled:text-text-secondary disabled:cursor-not-allowed"
          >
            {isAnswered ? (currentQuestionIndex < questions.length - 1 ? 'Next Question' : 'Finish Quiz') : 'Submit Answer'}
          </button>
        </div>
      );
    }

    return null;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-base-300 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center p-4 border-b border-base-200 sticky top-0 bg-base-300">
          <h2 className="text-xl font-bold">Test Your Knowledge: <span className="text-brand-accent">{skill}</span></h2>
          <button onClick={onClose} className="text-text-secondary hover:text-text-primary text-2xl">&times;</button>
        </div>
        {renderContent()}
      </div>
    </div>
  );
};

export default QuizModal;