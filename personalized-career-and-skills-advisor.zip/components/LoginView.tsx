
import React, { useState } from 'react';

interface LoginViewProps {
  onLogin: (user: { id: string; name: string; }) => void;
}

const LoginView: React.FC<LoginViewProps> = ({ onLogin }) => {
  const [name, setName] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      // Use a consistent hash of the name as a unique ID for local storage.
      // This is a simple way to create a stable ID.
      const generateId = (str: string) => {
          let hash = 0;
          for (let i = 0; i < str.length; i++) {
              const char = str.charCodeAt(i);
              hash = ((hash << 5) - hash) + char;
              hash |= 0; // Convert to 32bit integer
          }
          return `user-${Math.abs(hash)}`;
      };

      const user = {
        id: generateId(name.trim()),
        name: name.trim(),
      };
      onLogin(user);
    }
  };

  return (
    <div className="min-h-screen bg-base-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-base-200 rounded-2xl shadow-2xl p-8 text-center border border-base-300">
        <div className="flex justify-center items-center mb-6">
          <div className="bg-brand-accent p-3 rounded-lg mr-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-base-100" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
          </div>
          <h1 className="text-3xl font-bold text-text-primary">Career Compass AI</h1>
        </div>
        <p className="text-text-secondary mb-8">Your personalized guide to the perfect career path. Enter your name to create a local profile and save your progress.</p>
        
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label htmlFor="name" className="sr-only">Full Name</label>
            <input 
              type="text" 
              id="name" 
              value={name} 
              onChange={e => setName(e.target.value)} 
              className="w-full bg-base-300 border border-base-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-brand-secondary focus:outline-none text-center" 
              placeholder="Enter Your Name" 
              required 
            />
          </div>
          <button 
            type="submit" 
            className="w-full bg-brand-secondary hover:bg-brand-primary text-white font-bold py-3 px-4 rounded-lg transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-base-200 focus:ring-brand-secondary"
          >
            Sign In & Save Progress
          </button>
        </form>

        <p className="text-xs text-text-secondary mt-6">
            Your progress is saved securely in your browser.
        </p>
      </div>
    </div>
  );
};

export default LoginView;