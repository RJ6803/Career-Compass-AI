import React, { useState, useEffect, useCallback } from 'react';
import { CareerPath, GroundingSource, JobInsightData } from '../types';
import { getJobMarketInsights } from '../services/geminiService';
import { LoadingSpinner } from './LoadingSpinner';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface JobInsightsViewProps {
  careerPath: CareerPath;
}

const DataCard: React.FC<{ title: string, children: React.ReactNode }> = ({ title, children }) => (
    <div className="bg-base-300 p-6 rounded-xl">
        <h2 className="text-2xl font-semibold mb-4 text-brand-accent">{title}</h2>
        {children}
    </div>
);

const JobInsightsView: React.FC<JobInsightsViewProps> = ({ careerPath }) => {
  const [insights, setInsights] = useState<JobInsightData | null>(null);
  const [sources, setSources] = useState<GroundingSource[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [country, setCountry] = useState<'USA' | 'India'>('USA');

  const fetchInsights = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await getJobMarketInsights(careerPath.title, country);
      setInsights(result.insights);
      setSources(result.sources);
    } catch (err) {
      console.error("Failed to get job insights:", err);
      setError("Could not fetch job market insights. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [careerPath, country]);

  useEffect(() => {
    fetchInsights();
  }, [fetchInsights]);

  if (isLoading) {
    return <div className="flex flex-col items-center justify-center h-full">
        <LoadingSpinner />
        <p className="mt-4 text-lg">Fetching real-time job market data...</p>
    </div>;
  }

  if (error) {
    return <div className="text-center text-red-400">{error}</div>;
  }
  
  const sortedSkills = insights?.inDemandSkills.slice().sort((a, b) => b.demandScore - a.demandScore);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl font-bold mb-2">Job Market Insights: <span className="text-brand-accent">{careerPath.title}</span></h1>
        <p className="text-text-secondary text-lg">Real-time data to help you navigate the job market.</p>
        <div className="mt-4 flex items-center space-x-2 bg-base-300 p-1 rounded-lg w-min">
            <button
                onClick={() => setCountry('USA')}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${country === 'USA' ? 'bg-brand-secondary text-white' : 'text-text-secondary hover:bg-base-200'}`}
            >
                USA
            </button>
            <button
                onClick={() => setCountry('India')}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${country === 'India' ? 'bg-brand-secondary text-white' : 'text-text-secondary hover:bg-base-200'}`}
            >
                India
            </button>
        </div>
      </div>
      
      {insights && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-8">
                <DataCard title="Average Salary Range">
                    <div className="text-center">
                        <p className="text-5xl font-bold text-text-primary">
                            {new Intl.NumberFormat('en-US', { style: 'currency', currency: insights.averageSalary.currency, minimumFractionDigits: 0 }).format(insights.averageSalary.min)} - {new Intl.NumberFormat('en-US', { style: 'currency', currency: insights.averageSalary.currency, minimumFractionDigits: 0 }).format(insights.averageSalary.max)}
                        </p>
                        <p className="text-text-secondary mt-2">per year in {country === 'USA' ? 'the United States' : 'India'}</p>
                        <div className={`mt-4 text-lg font-bold ${insights.demand === 'High' ? 'text-green-400' : insights.demand === 'Medium' ? 'text-yellow-400' : 'text-red-400'}`}>
                            Current Demand: {insights.demand}
                        </div>
                    </div>
                </DataCard>
                <DataCard title="Market Summary">
                    <p className="text-text-secondary">{insights.summary}</p>
                </DataCard>
                <DataCard title="Future Outlook">
                    <p className="text-text-secondary">{insights.futureOutlook}</p>
                </DataCard>
            </div>
            <DataCard title="In-Demand Skills">
                <div className="h-96">
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={sortedSkills} layout="vertical" margin={{ top: 5, right: 20, left: 30, bottom: 5 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#21262d" />
                            <XAxis type="number" domain={[0, 100]} stroke="#8b949e" />
                            <YAxis type="category" dataKey="skill" width={100} stroke="#8b949e" tick={{ fill: '#c9d1d9', fontSize: 12 }} />
                            <Tooltip cursor={{fill: 'rgba(59, 130, 246, 0.1)'}} contentStyle={{ backgroundColor: '#161b22', border: '1px solid #21262d' }} />
                            <Bar dataKey="demandScore" barSize={15}>
                                {sortedSkills?.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={'#2dd4bf'} />
                                ))}
                            </Bar>
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </DataCard>
        </div>
      )}

      {sources.length > 0 && (
          <div className="mt-8">
              <h2 className="text-2xl font-semibold mb-4">Sources</h2>
              <div className="bg-base-300 p-6 rounded-xl space-y-3">
                {sources.map((source, index) => (
                    source.web && <a href={source.web.uri} key={index} target="_blank" rel="noopener noreferrer" className="block p-3 bg-base-200 rounded-lg hover:bg-base-100 transition-colors">
                        <p className="font-semibold text-brand-secondary">{source.web.title}</p>
                        <p className="text-xs text-text-secondary truncate">{source.web.uri}</p>
                    </a>
                ))}
              </div>
          </div>
      )}
    </div>
  );
};

export default JobInsightsView;