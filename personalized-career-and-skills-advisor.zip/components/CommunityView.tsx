import React from 'react';

const CommunityCard: React.FC<{ title: string; description: string; buttonText: string; icon: JSX.Element, href?: string }> = ({ title, description, buttonText, icon, href }) => (
    <div className="bg-base-300 p-6 rounded-xl flex flex-col items-start">
        <div className="bg-brand-secondary p-3 rounded-lg mb-4">
            {icon}
        </div>
        <h3 className="text-xl font-bold text-text-primary mb-2">{title}</h3>
        <p className="text-text-secondary mb-4 flex-grow">{description}</p>
        <a href={href || "#"} target="_blank" rel="noopener noreferrer" className="mt-auto bg-brand-accent hover:bg-teal-500 text-base-100 font-bold py-2 px-4 rounded-lg transition-colors duration-300">
            {buttonText}
        </a>
    </div>
);

const CommunityView: React.FC = () => {
    return (
        <div className="space-y-8">
            <div>
                <h1 className="text-4xl font-bold mb-2">Community Hub</h1>
                <p className="text-text-secondary text-lg">Connect with peers, get help, and grow together.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <CommunityCard 
                    title="Join our Discord Server"
                    description="Chat in real-time with fellow learners and professionals. Get instant help, share your progress, and find project collaborators."
                    buttonText="Join Discord"
                    icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="currentColor" viewBox="0 0 24 24" stroke="currentColor"><path d="M19.54,5.54a9.72,9.72,0,0,0-5.8-1.5,9.22,9.22,0,0,0-6,1.72A10,10,0,0,0,4.26,12a10.26,10.26,0,0,0,3.38,7.24,9.52,9.52,0,0,0,6.1,2.26,9.44,9.44,0,0,0,5.8-1.5,5.3,5.3,0,0,1-2.18-1.72,7.45,7.45,0,0,1-3.62.82,7.84,7.84,0,0,1-3.62-1,8.3,8.3,0,0,0,2.18-1.46,8.28,8.28,0,0,0-2.46-4.58,10.36,10.36,0,0,1,5.24.58,6,6,0,0,0,1.5-.2,1,1,0,0,0,.5-.58,7.38,7.38,0,0,0,1.14-3.32A5.63,5.63,0,0,0,19.54,5.54Z" /></svg>}
                    href="https://discord.com" // Placeholder link
                />
                <CommunityCard 
                    title="Discussion Forums"
                    description="Ask in-depth technical questions, discuss career strategies, and share valuable resources in our structured forum."
                    buttonText="Go to Forums"
                    icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>}
                />
                <CommunityCard 
                    title="Job Referrals"
                    description="Connect with others in the industry and discover job opportunities through peer-to-peer referrals. Expand your network."
                    buttonText="Browse Referrals"
                    icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>}
                />
            </div>
        </div>
    );
};

export default CommunityView;