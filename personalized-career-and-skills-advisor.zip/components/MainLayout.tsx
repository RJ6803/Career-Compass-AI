import React, { useState, useEffect } from 'react';
import { UserProfile, CareerPath } from '../types';
import Sidebar from './Sidebar';
import Dashboard from './Dashboard';
import SkillRoadmapView from './SkillRoadmapView';
import JobInsightsView from './JobInsightsView';
import JobOpeningsView from './JobOpeningsView';
import CommunityView from './CommunityView';
import Chatbot from './Chatbot';
import ProfileEditView from './ProfileEditView';

interface MainLayoutProps {
  userProfile: UserProfile;
  careerPaths: CareerPath[];
  onLogout: () => void;
  onResetProfile: () => void;
  onUpdateProfile: (profile: UserProfile) => void;
  onRefreshRecommendations: () => void;
  isUpdatingRecommendations: boolean;
  userId: string;
}

type ActiveView = 'dashboard' | 'roadmap' | 'insights' | 'jobs' | 'community' | 'editProfile';

const MainLayout: React.FC<MainLayoutProps> = ({ userProfile, careerPaths, onLogout, onResetProfile, onUpdateProfile, onRefreshRecommendations, isUpdatingRecommendations, userId }) => {
  const [activeView, setActiveView] = useState<ActiveView>('dashboard');
  const [selectedCareer, setSelectedCareer] = useState<CareerPath | undefined>(careerPaths[0]);

  useEffect(() => {
    if (careerPaths.length > 0) {
      // If a career is already selected, check if it's still in the list.
      // If not, or if nothing is selected, default to the first career path.
      const isSelectedCareerValid = selectedCareer && careerPaths.some(p => p.title === selectedCareer.title);
      if (!isSelectedCareerValid) {
        setSelectedCareer(careerPaths[0]);
      }
    } else {
      // If there are no career paths, clear the selection.
      setSelectedCareer(undefined);
    }
  }, [careerPaths, selectedCareer]);

  const handleSkillLearned = (skill: string) => {
    const isAlreadyLearned = userProfile.skills.map(s => s.toLowerCase()).includes(skill.toLowerCase());
    let updatedSkills;

    if (isAlreadyLearned) {
      // If skill is already learned, unchecking removes it
      updatedSkills = userProfile.skills.filter(s => s.toLowerCase() !== skill.toLowerCase());
    } else {
      // If skill is not learned, checking adds it
      updatedSkills = [...userProfile.skills, skill];
    }
    
    const updatedProfile = {
      ...userProfile,
      skills: updatedSkills,
    };
    onUpdateProfile(updatedProfile);
  };
  
  const handleRewardEarned = (amount: number) => {
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0]; // YYYY-MM-DD

    // If they already completed a quiz today, just add coins
    if (userProfile.lastQuizDate === todayStr) {
        const updatedProfile = {
            ...userProfile,
            coins: (userProfile.coins || 0) + amount,
        };
        onUpdateProfile(updatedProfile);
        return;
    }
    
    const yesterday = new Date(today);
    yesterday.setDate(today.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];

    let newStreak = userProfile.dailyStreak || 0;

    if (userProfile.lastQuizDate === yesterdayStr) {
        // Streak continues
        newStreak += 1;
    } else {
        // Streak is broken or it's the first one
        newStreak = 1;
    }

    const updatedProfile = {
        ...userProfile,
        coins: (userProfile.coins || 0) + amount,
        dailyStreak: newStreak,
        lastQuizDate: todayStr,
    };
    onUpdateProfile(updatedProfile);
  };
  
  const handleUpdateRoadmapDuration = (careerTitle: string, duration: string) => {
    const updatedProfile: UserProfile = {
        ...userProfile,
        roadmapDurations: {
            ...(userProfile.roadmapDurations || {}),
            [careerTitle]: duration,
        }
    };
    onUpdateProfile(updatedProfile);
  };

  const renderContent = () => {
    // These views require a selected career. If none exists, show a placeholder.
    if (['roadmap', 'insights', 'jobs'].includes(activeView) && !selectedCareer) {
        return (
            <div className="flex flex-col items-center justify-center h-full text-center">
                <h2 className="text-2xl font-bold">No Career Path Selected</h2>
                <p className="mt-2 text-text-secondary">Please select a career from the Dashboard to see more details.</p>
            </div>
        );
    }

    switch (activeView) {
      case 'dashboard':
        return <Dashboard userProfile={userProfile} careerPaths={careerPaths} onSelectCareer={setSelectedCareer} activeCareer={selectedCareer} onRefreshRecommendations={onRefreshRecommendations} isUpdatingRecommendations={isUpdatingRecommendations} />;
      case 'roadmap':
        return <SkillRoadmapView careerPath={selectedCareer!} userProfile={userProfile} onSkillLearned={handleSkillLearned} onRewardEarned={handleRewardEarned} userId={userId} onUpdateRoadmapDuration={handleUpdateRoadmapDuration} />;
      case 'insights':
        return <JobInsightsView careerPath={selectedCareer!} />;
      case 'jobs':
        return <JobOpeningsView careerPath={selectedCareer!} userProfile={userProfile} />;
      case 'community':
        return <CommunityView />;
      case 'editProfile':
        return <ProfileEditView 
                  userProfile={userProfile} 
                  onUpdateProfile={onUpdateProfile}
                  onSaveComplete={() => setActiveView('dashboard')} 
               />;
      default:
        return <Dashboard userProfile={userProfile} careerPaths={careerPaths} onSelectCareer={setSelectedCareer} activeCareer={selectedCareer} onRefreshRecommendations={onRefreshRecommendations} isUpdatingRecommendations={isUpdatingRecommendations}/>;
    }
  };

  return (
    <div className="flex min-h-screen bg-base-200">
      <Sidebar activeView={activeView} setActiveView={setActiveView} onLogout={onLogout} onResetProfile={onResetProfile} userProfile={userProfile} />
      <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
        {renderContent()}
      </main>
      <Chatbot userProfile={userProfile} />
    </div>
  );
};

export default MainLayout;