import React from 'react';
import { UserProfile } from '../types';

interface SidebarProps {
  activeView: string;
  setActiveView: (view: 'dashboard' | 'roadmap' | 'insights' | 'jobs' | 'community' | 'editProfile') => void;
  onLogout: () => void;
  onResetProfile: () => void;
  userProfile: UserProfile;
}

const NavItem: React.FC<{ icon: React.ReactElement<{ className?: string }>; label: string; isActive: boolean; onClick: () => void }> = ({ icon, label, isActive, onClick }) => (
    <button 
        onClick={onClick}
        className={`flex items-center w-full px-4 py-3 text-left rounded-lg transition-colors duration-200 ${isActive ? 'bg-brand-secondary text-white' : 'text-text-secondary hover:bg-base-300 hover:text-text-primary'}`}
    >
        {React.cloneElement(icon, { className: "w-6 h-6 mr-3"})}
        <span className="font-medium">{label}</span>
    </button>
);


const Sidebar: React.FC<SidebarProps> = ({ activeView, setActiveView, onLogout, onResetProfile, userProfile }) => {
  
  const handleResetClick = () => {
    if (window.confirm('Are you sure you want to reset your profile? This will delete your generated career path and all related progress. This action cannot be undone.')) {
        onResetProfile();
    }
  };

  return (
    <aside className="w-64 bg-base-100 flex-shrink-0 p-4 border-r border-base-300 flex flex-col">
      <div className="flex items-center mb-8">
        <div className="bg-brand-accent p-2 rounded-lg mr-3">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-base-100" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657 13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
        </div>
        <h1 className="text-xl font-bold">Career Compass</h1>
      </div>

      <div className="flex flex-col items-center mb-8 text-center">
        <img src={userProfile.photo || `https://api.pravatar.cc/150?u=${userProfile.name}`} alt={userProfile.name} className="w-24 h-24 rounded-full mb-3 border-4 border-base-300 object-cover" />
        <h2 className="text-lg font-semibold">{userProfile.name}</h2>
        <p className="text-sm text-text-secondary">{userProfile.education}</p>
        {userProfile.email && (
            <p className="text-xs text-text-secondary truncate w-full px-2">{userProfile.email}</p>
        )}
        <button 
            onClick={() => setActiveView('editProfile')} 
            className="mt-2 flex items-center text-sm text-brand-secondary hover:text-brand-accent transition-colors"
            aria-label="Edit profile"
        >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L15.232 5.232z" /></svg>
            Edit Profile
        </button>
      </div>

      <nav className="flex flex-col space-y-2">
        <NavItem icon={<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" /></svg>} label="Dashboard" isActive={activeView === 'dashboard'} onClick={() => setActiveView('dashboard')} />
        <NavItem icon={<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l5.447 2.724A1 1 0 0021 16.382V5.618a1 1 0 00-1.447-.894L15 7m-6 3l6-3" /></svg>} label="Skill Roadmap" isActive={activeView === 'roadmap'} onClick={() => setActiveView('roadmap')} />
        <NavItem icon={<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>} label="Job Insights" isActive={activeView === 'insights'} onClick={() => setActiveView('insights')} />
        <NavItem icon={<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" ><path strokeLinecap="round" strokeLinejoin="round" d="M20.25 14.15v4.07a2.25 2.25 0 01-2.25 2.25H5.998a2.25 2.25 0 01-2.25-2.25v-4.07a2.25 2.25 0 012.25-2.25h1.5a2.25 2.25 0 012.25 2.25v.075a2.25 2.25 0 002.25 2.25h3a2.25 2.25 0 002.25-2.25V12a2.25 2.25 0 012.25-2.25h1.5a2.25 2.25 0 012.25 2.25z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0z" /></svg>} label="Job Openings" isActive={activeView === 'jobs'} onClick={() => setActiveView('jobs')} />
        <NavItem icon={<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m-7.5-2.962A3.75 3.75 0 019 12a3.75 3.75 0 015.026-3.412 3.75 3.75 0 010 6.824A3.75 3.75 0 019 12z" /><path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72M6.344 18.72A3 3 0 002.406 15.44l-2.406-1.04a2.25 2.25 0 00-1.082 3.858 9.095 9.095 0 005.418 2.962" /></svg>} label="Community" isActive={activeView === 'community'} onClick={() => setActiveView('community')} />
      </nav>
      
      <div className="mt-auto">
         <div className="grid grid-cols-2 gap-2">
            <div className="bg-base-300 rounded-lg p-3 text-center">
                <h3 className="font-semibold text-sm">Daily Streak</h3>
                <p className="text-2xl font-bold text-brand-accent">🔥 {userProfile.dailyStreak || 0}</p>
            </div>
            <div className="bg-base-300 rounded-lg p-3 text-center">
                <h3 className="font-semibold text-sm">Reward Coins</h3>
                <p className="text-2xl font-bold text-yellow-400">💰 {userProfile.coins || 0}</p>
            </div>
         </div>
         <div className="flex items-center space-x-2 mt-4">
            <button onClick={handleResetClick} title="Reset Profile" className="flex items-center justify-center w-full px-4 py-3 text-text-secondary hover:bg-yellow-900 hover:text-white rounded-lg transition-colors duration-200">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h5M20 20v-5h-5M4 4l5 5M20 20l-5-5M15 4h5v5" /></svg>
                <span className="ml-2">Reset Profile</span>
            </button>
            <button onClick={onLogout} title="Logout" className="flex items-center justify-center w-full px-4 py-3 text-text-secondary hover:bg-red-900 hover:text-white rounded-lg transition-colors duration-200">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
                <span className="ml-2">Logout</span>
            </button>
         </div>
      </div>

    </aside>
  );
};

export default Sidebar;