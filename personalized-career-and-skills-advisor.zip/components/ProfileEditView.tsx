import React, { useState, ChangeEvent } from 'react';
import { UserProfile } from '../types';

interface ProfileEditViewProps {
  userProfile: UserProfile;
  onUpdateProfile: (profile: UserProfile) => void;
  onSaveComplete: () => void;
}

const Chip: React.FC<{ text: string; onRemove: () => void }> = ({ text, onRemove }) => (
  <div className="flex items-center bg-brand-secondary text-white text-sm font-medium px-3 py-1 rounded-full">
    <span>{text}</span>
    <button onClick={onRemove} className="ml-2 text-white hover:text-brand-light focus:outline-none">
      &times;
    </button>
  </div>
);

const ProfileEditView: React.FC<ProfileEditViewProps> = ({ userProfile, onUpdateProfile, onSaveComplete }) => {
  const [formData, setFormData] = useState<UserProfile>(userProfile);
  const [photoPreview, setPhotoPreview] = useState<string | undefined>(userProfile.photo);
  const [currentSkill, setCurrentSkill] = useState('');

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handlePhotoChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setFormData(prev => ({ ...prev, photo: base64String }));
        setPhotoPreview(base64String);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddSkill = () => {
    if (currentSkill.trim() && !formData.skills.map(s => s.toLowerCase()).includes(currentSkill.trim().toLowerCase())) {
        setFormData(prev => ({ ...prev, skills: [...prev.skills, currentSkill.trim()] }));
    }
    setCurrentSkill('');
  };

  const handleSkillKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
      if (e.key === 'Enter' || e.key === ',') {
          e.preventDefault();
          handleAddSkill();
      }
  };

  const removeSkill = (index: number) => {
      setFormData(prev => ({ ...prev, skills: prev.skills.filter((_, i) => i !== index) }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile(formData);
    onSaveComplete();
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-4xl font-bold mb-8">Edit Profile</h1>
      <form onSubmit={handleSubmit} className="bg-base-300 p-8 rounded-xl space-y-6">
        <div className="flex items-center space-x-6">
          <img
            src={photoPreview || `https://api.pravatar.cc/150?u=${formData.name}`}
            alt="Profile Preview"
            className="w-32 h-32 rounded-full object-cover border-4 border-base-200"
          />
          <div>
            <label htmlFor="photo-upload" className="cursor-pointer bg-brand-secondary hover:bg-brand-primary text-white font-bold py-2 px-4 rounded-lg transition-colors duration-300">
              Upload New Photo
            </label>
            <input id="photo-upload" type="file" accept="image/*" onChange={handlePhotoChange} className="hidden" />
            <p className="text-sm text-text-secondary mt-2">Recommended: Square image, .jpg or .png</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-text-secondary mb-2">Full Name</label>
            <input type="text" id="name" value={formData.name} onChange={handleChange} className="w-full bg-base-200 border border-base-200 rounded-lg px-4 py-2 focus:ring-2 focus:ring-brand-secondary focus:outline-none" required />
          </div>
          <div>
            <label htmlFor="education" className="block text-sm font-medium text-text-secondary mb-2">Highest Education / College</label>
            <input type="text" id="education" value={formData.education} onChange={handleChange} className="w-full bg-base-200 border border-base-200 rounded-lg px-4 py-2 focus:ring-2 focus:ring-brand-secondary focus:outline-none" required />
          </div>
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-text-secondary mb-2">Email ID</label>
            <input type="email" id="email" value={formData.email || ''} onChange={handleChange} className="w-full bg-base-200 border border-base-200 rounded-lg px-4 py-2 focus:ring-2 focus:ring-brand-secondary focus:outline-none" placeholder="your.email@example.com" />
          </div>
          <div>
            <label htmlFor="phone" className="block text-sm font-medium text-text-secondary mb-2">Phone No.</label>
            <input type="tel" id="phone" value={formData.phone || ''} onChange={handleChange} className="w-full bg-base-200 border border-base-200 rounded-lg px-4 py-2 focus:ring-2 focus:ring-brand-secondary focus:outline-none" placeholder="+1 (555) 123-4567" />
          </div>
          <div>
            <label htmlFor="dob" className="block text-sm font-medium text-text-secondary mb-2">Date of Birth</label>
            <input type="date" id="dob" value={formData.dob || ''} onChange={handleChange} className="w-full bg-base-200 border border-base-200 rounded-lg px-4 py-2 focus:ring-2 focus:ring-brand-secondary focus:outline-none" />
          </div>
          <div>
            <label htmlFor="linkedin" className="block text-sm font-medium text-text-secondary mb-2">LinkedIn Profile URL</label>
            <input type="url" id="linkedin" value={formData.linkedin || ''} onChange={handleChange} className="w-full bg-base-200 border border-base-200 rounded-lg px-4 py-2 focus:ring-2 focus:ring-brand-secondary focus:outline-none" placeholder="https://linkedin.com/in/..." />
          </div>
          <div>
            <label htmlFor="github" className="block text-sm font-medium text-text-secondary mb-2">GitHub Profile URL</label>
            <input type="url" id="github" value={formData.github || ''} onChange={handleChange} className="w-full bg-base-200 border border-base-200 rounded-lg px-4 py-2 focus:ring-2 focus:ring-brand-secondary focus:outline-none" placeholder="https://github.com/..." />
          </div>
          <div>
            <label htmlFor="resumeUrl" className="block text-sm font-medium text-text-secondary mb-2">Resume URL (Optional)</label>
            <input type="url" id="resumeUrl" value={formData.resumeUrl || ''} onChange={handleChange} className="w-full bg-base-200 border border-base-200 rounded-lg px-4 py-2 focus:ring-2 focus:ring-brand-secondary focus:outline-none" placeholder="https://example.com/your-resume.pdf" />
          </div>
        </div>
        
        <div>
            <label className="block text-sm font-medium text-text-secondary mb-2">Display Theme</label>
            <div className="flex items-center space-x-2 bg-base-200 p-1 rounded-lg">
                {(['light', 'dark', 'default'] as const).map((themeOption) => (
                    <button
                        key={themeOption}
                        type="button"
                        onClick={() => setFormData(prev => ({ ...prev, theme: themeOption }))}
                        className={`flex-1 px-4 py-2 rounded-md text-sm font-medium transition-colors capitalize ${(formData.theme || 'default') === themeOption ? 'bg-brand-secondary text-white' : 'text-text-secondary hover:bg-base-100'}`}
                    >
                        {themeOption}
                    </button>
                ))}
            </div>
        </div>

        <div>
            <label htmlFor="skills" className="block text-sm font-medium text-text-secondary mb-2">Your Skills (add with Enter or comma)</label>
            <div className="flex flex-wrap gap-2 p-2 bg-base-200 border border-base-200 rounded-lg">
                {formData.skills.map((skill, i) => <Chip key={i} text={skill} onRemove={() => removeSkill(i)} />)}
                <input 
                    type="text" 
                    id="skills-input"
                    value={currentSkill} 
                    onChange={e => setCurrentSkill(e.target.value)} 
                    onKeyDown={handleSkillKeyDown} 
                    className="flex-grow bg-transparent focus:outline-none p-1" 
                    placeholder="Add a new skill..." 
                />
            </div>
        </div>

        <div className="flex justify-end space-x-4 pt-4">
          <button type="button" onClick={onSaveComplete} className="bg-base-200 hover:bg-base-100 text-text-primary font-bold py-2 px-6 rounded-lg transition-colors duration-300">
            Cancel
          </button>
          <button type="submit" className="bg-brand-accent hover:bg-teal-500 text-base-100 font-bold py-2 px-6 rounded-lg transition-colors duration-300">
            Save Changes
          </button>
        </div>
      </form>
    </div>
  );
};

export default ProfileEditView;