import React from 'react';
import { UserProfile, CareerPath } from '../types';

interface SkillGapAnalysisProps {
  userProfile: UserProfile;
  careerPath: CareerPath;
}

const SkillGapAnalysis: React.FC<SkillGapAnalysisProps> = ({ userProfile, careerPath }) => {
  // Case-insensitive matching
  const userSkillsSet = new Set(userProfile.skills.map(s => s.toLowerCase()));
  const requiredSkills = careerPath.requiredSkills;

  const learnedSkills = requiredSkills.filter(skill => userSkillsSet.has(skill.toLowerCase()));
  const skillsToLearn = requiredSkills.filter(skill => !userSkillsSet.has(skill.toLowerCase()));

  const completionPercentage = requiredSkills.length > 0 ? (learnedSkills.length / requiredSkills.length) * 100 : 0;

  return (
    <div className="bg-base-300 p-6 rounded-xl">
      <h2 className="text-2xl font-semibold mb-4">Skill Analysis: <span className="text-brand-accent">{careerPath.title}</span></h2>
      
      <div>
        <div className="flex justify-between mb-1">
          <span className="text-base font-medium text-text-primary">Skill Match</span>
          <span className="text-sm font-medium text-text-primary">{Math.round(completionPercentage)}%</span>
        </div>
        <div className="w-full bg-base-200 rounded-full h-2.5">
          <div className="bg-brand-accent h-2.5 rounded-full transition-all duration-500" style={{ width: `${completionPercentage}%` }}></div>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h3 className="font-semibold text-lg mb-3 flex items-center text-green-400">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
            </svg>
            Your Skills ({learnedSkills.length})
          </h3>
          <ul className="space-y-2 max-h-32 overflow-y-auto pr-2">
            {learnedSkills.length > 0 ? learnedSkills.map(skill => (
              <li key={skill} className="text-sm text-text-primary">{skill}</li>
            )) : <p className="text-sm text-text-secondary italic">No matching skills from this path yet.</p>}
          </ul>
        </div>
        <div>
          <h3 className="font-semibold text-lg mb-3 flex items-center text-yellow-400">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
               <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 102 0V6zM10 14a1 1 0 110-2 1 1 0 010 2z" clipRule="evenodd" />
            </svg>
            Skill Gaps ({skillsToLearn.length})
          </h3>
          <ul className="space-y-2 max-h-32 overflow-y-auto pr-2">
             {skillsToLearn.length > 0 ? skillsToLearn.map(skill => (
              <li key={skill} className="text-sm text-text-primary font-medium">{skill}</li>
            )) : <p className="text-sm text-text-secondary italic">All required skills acquired!</p>}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default SkillGapAnalysis;
