import React, { useState, useEffect, useCallback } from 'react';
import { CareerPath, UserProfile, SkillRoadmap, SkillRoadmapStage } from '../types';
import { getSkillRoadmap } from '../services/geminiService';
import { LoadingSpinner } from './LoadingSpinner';
import SkillGapAnalysis from './SkillGapAnalysis';
import QuizModal from './QuizModal';

interface SkillRoadmapViewProps {
  careerPath: CareerPath;
  userProfile: UserProfile;
  onSkillLearned: (skill: string) => void;
  onRewardEarned: (amount: number) => void;
  userId: string;
  onUpdateRoadmapDuration: (careerTitle: string, duration: string) => void;
}

type DurationOption = {
    key: string;
    name: string;
    description: string;
};
const durationOptions: DurationOption[] = [
    { key: '1-month', name: 'Intensive', description: '1 Month' },
    { key: '3-months', name: 'Standard', description: '3 Months' },
    { key: '6-months', name: 'Casual', description: '6 Months' },
];

const ProgressBar: React.FC<{ percentage: number; title?: string }> = ({ percentage, title }) => (
    <div>
        {title && (
            <div className="flex justify-between mb-1">
                <span className="text-base font-medium text-text-primary">{title}</span>
                <span className="text-sm font-medium text-text-primary">{Math.round(percentage)}%</span>
            </div>
        )}
        <div className="w-full bg-base-100 rounded-full h-2.5">
            <div className="bg-brand-accent h-2.5 rounded-full transition-all duration-500" style={{ width: `${percentage}%` }}></div>
        </div>
    </div>
);


const StageCard: React.FC<{ 
    stage: SkillRoadmapStage; 
    index: number; 
    learnedSkills: string[]; 
    onSkillLearned: (skill: string) => void; 
    onTestKnowledge: (skill: string) => void;
}> = ({ stage, index, learnedSkills, onSkillLearned, onTestKnowledge }) => {
    const colors = ['border-blue-500', 'border-teal-400', 'border-purple-500'];
    const bgColor = ['bg-blue-900/20', 'bg-teal-900/20', 'bg-purple-900/20'];
    const learnedSkillsSet = new Set(learnedSkills.map(s => s.toLowerCase()));

    const stageLearnedCount = stage.skillsToLearn.filter(s => learnedSkillsSet.has(s.toLowerCase())).length;
    const stageTotalSkills = stage.skillsToLearn.length;
    const stageCompletion = stageTotalSkills > 0 ? (stageLearnedCount / stageTotalSkills) * 100 : 0;

    return (
        <div className="relative pl-8">
            <div className={`absolute top-0 left-0 h-full w-0.5 ${colors[index % colors.length]}`}></div>
            <div className={`absolute top-2 left-[-9px] w-5 h-5 rounded-full ${colors[index % colors.length].replace('border', 'bg')} border-4 border-base-200`}></div>
            <div className={`mb-8 p-6 rounded-lg ${bgColor[index % colors.length]}`}>
                <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-4">
                    <div>
                        <h3 className="text-2xl font-bold text-brand-accent">{`${index + 1}. ${stage.stageName}`}</h3>
                        {stage.estimatedTime && (
                           <p className="text-sm text-text-secondary font-medium mt-1">Estimated Time: {stage.estimatedTime}</p>
                        )}
                    </div>
                    <div className="w-full sm:w-1/3 mt-2 sm:mt-0">
                        <ProgressBar percentage={stageCompletion} title="Stage Progress" />
                    </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                        <h4 className="font-semibold text-lg mb-2">Skills to Learn</h4>
                        <ul className="space-y-2">
                            {stage.skillsToLearn.map((skill, i) => {
                                const isLearned = learnedSkillsSet.has(skill.toLowerCase());
                                return (
                                <li key={i} className="flex items-center justify-between">
                                    <div className="flex items-center">
                                        <input 
                                            type="checkbox"
                                            id={`${stage.stageName}-${skill}`}
                                            checked={isLearned}
                                            onChange={() => onSkillLearned(skill)}
                                            className="h-4 w-4 rounded border-gray-300 text-brand-secondary focus:ring-brand-secondary"
                                        />
                                        <label htmlFor={`${stage.stageName}-${skill}`} className={`ml-3 ${isLearned ? 'line-through text-text-secondary' : 'text-text-primary'}`}>
                                            {skill}
                                        </label>
                                    </div>
                                    {isLearned && (
                                        <button
                                            onClick={() => onTestKnowledge(skill)}
                                            className="text-xs bg-brand-accent text-base-100 px-2 py-1 rounded-md hover:bg-teal-500 transition-colors"
                                        >
                                            Test Knowledge
                                        </button>
                                    )}
                                </li>
                            )})}
                        </ul>
                    </div>
                    <div>
                        <h4 className="font-semibold text-lg mb-2">Recommended Resources</h4>
                        <ul className="space-y-2">
                            {stage.resources.map((res, i) => (
                                <li key={i}><a href={res.url} target="_blank" rel="noopener noreferrer" className="text-brand-secondary hover:underline">{res.name} ↗</a></li>
                            ))}
                        </ul>
                    </div>
                    <div>
                        <h4 className="font-semibold text-lg mb-2">Project Ideas</h4>
                        <ul className="list-disc list-inside text-text-secondary space-y-1">
                            {stage.projectIdeas.map((proj, i) => <li key={i}>{proj}</li>)}
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    );
};


const SkillRoadmapView: React.FC<SkillRoadmapViewProps> = ({ careerPath, userProfile, onSkillLearned, onRewardEarned, userId, onUpdateRoadmapDuration }) => {
  const [roadmap, setRoadmap] = useState<SkillRoadmap | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [isQuizOpen, setIsQuizOpen] = useState(false);
  const [selectedSkillForQuiz, setSelectedSkillForQuiz] = useState<string | null>(null);

  const activeDuration = userProfile.roadmapDurations?.[careerPath.title] || '3-months';

  useEffect(() => {
    const fetchRoadmap = async () => {
        setIsLoading(true);
        setError(null);
        setRoadmap(null);

        const durationInfo = durationOptions.find(d => d.key === activeDuration);
        const durationText = `${durationInfo?.description} (${durationInfo?.name})`;
        const storageKey = `careerCompassRoadmap_${userId}_${careerPath.title}_${activeDuration}`;

        try {
            const cachedRoadmap = localStorage.getItem(storageKey);
            if (cachedRoadmap) {
                setRoadmap(JSON.parse(cachedRoadmap));
            } else {
                const result = await getSkillRoadmap(careerPath, durationText);
                setRoadmap(result);
                localStorage.setItem(storageKey, JSON.stringify(result));
            }
        } catch (err) {
            console.error("Failed to get skill roadmap:", err);
            setError("Could not generate a skill roadmap for this career. Please try again.");
        } finally {
            setIsLoading(false);
        }
    };
    
    if (userId && careerPath) {
      fetchRoadmap();
    }
  }, [careerPath, userId, activeDuration]);


  const handleTestKnowledge = (skill: string) => {
    setSelectedSkillForQuiz(skill);
    setIsQuizOpen(true);
  };

  const handleQuizComplete = (reward: number) => {
    onRewardEarned(reward);
    setIsQuizOpen(false);
    setSelectedSkillForQuiz(null);
  };

  const learnedSkillsSet = new Set(userProfile.skills.map(s => s.toLowerCase()));
  const totalSkills = roadmap?.stages.reduce((acc, stage) => acc + stage.skillsToLearn.length, 0) || 0;
  const totalLearnedSkills = roadmap?.stages.reduce((acc, stage) => {
      return acc + stage.skillsToLearn.filter(skill => learnedSkillsSet.has(skill.toLowerCase())).length;
  }, 0) || 0;
  const overallCompletion = totalSkills > 0 ? (totalLearnedSkills / totalSkills) * 100 : 0;

  if (isLoading) {
    return <div className="flex flex-col items-center justify-center h-full">
        <LoadingSpinner />
        <p className="mt-4 text-lg">Generating your personalized skill roadmap...</p>
    </div>;
  }

  if (error) {
    return <div className="text-center text-red-400">{error}</div>;
  }

  return (
    <div>
      <h1 className="text-4xl font-bold mb-2">Skill Roadmap: <span className="text-brand-accent">{careerPath.title}</span></h1>
      <p className="text-text-secondary text-lg mb-6">Your personalized step-by-step guide to becoming a {careerPath.title}. Check off skills as you learn them!</p>
      
      <div className="bg-base-300 p-4 rounded-xl mb-8 space-y-4">
         <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <label className="text-sm font-medium text-text-secondary whitespace-nowrap">CUSTOMIZE DURATION:</label>
            <div className="flex items-center space-x-2 bg-base-100 p-1 rounded-lg flex-wrap gap-y-1 justify-center">
              {durationOptions.map(option => (
                <button
                  key={option.key}
                  onClick={() => onUpdateRoadmapDuration(careerPath.title, option.key)}
                  className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${activeDuration === option.key ? 'bg-brand-secondary text-white' : 'text-text-secondary hover:bg-base-200'}`}
                >
                  {option.name} ({option.description})
                </button>
              ))}
            </div>
        </div>
        {roadmap && <ProgressBar percentage={overallCompletion} title="Overall Roadmap Progress" />}
      </div>

      <div className="mb-8">
        <SkillGapAnalysis userProfile={userProfile} careerPath={careerPath} />
      </div>
      
      {roadmap && (
        <div className="mt-8">
            {roadmap.stages.map((stage, index) => (
                <StageCard 
                    key={index} 
                    stage={stage} 
                    index={index} 
                    learnedSkills={userProfile.skills} 
                    onSkillLearned={onSkillLearned}
                    onTestKnowledge={handleTestKnowledge}
                />
            ))}
        </div>
      )}

      {isQuizOpen && selectedSkillForQuiz && (
        <QuizModal 
            skill={selectedSkillForQuiz}
            onClose={() => setIsQuizOpen(false)}
            onQuizComplete={handleQuizComplete}
        />
      )}
    </div>
  );
};

export default SkillRoadmapView;