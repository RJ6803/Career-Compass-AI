
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, Chat } from "@google/genai";
import { UserProfile, ChatMessage } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const Chatbot: React.FC<{ userProfile: UserProfile }> = ({ userProfile }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [userInput, setUserInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [chat, setChat] = useState<Chat | null>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const skillsDescription = userProfile.skills.length > 0
            ? `Their current skills are ${userProfile.skills.join(', ')}.`
            : 'They are a beginner and have not listed any skills yet.';

        const systemInstruction = `You are an expert career and skills advisor called 'Career Compass AI'. You are talking to ${userProfile.name}, whose education is in ${userProfile.education}. ${skillsDescription} They are interested in ${userProfile.interests.join(', ')}. Your role is to provide supportive, insightful, and personalized advice. You can answer questions about career paths, suggest learning resources, help with skill development, and offer insights into the job market. Be encouraging and proactive in helping them achieve their career goals. Keep your responses concise and easy to read.`;

        const chatSession = ai.chats.create({
            model: 'gemini-2.5-flash',
            config: {
                systemInstruction,
            },
        });
        setChat(chatSession);

        setMessages([
            { role: 'model', content: `Hi ${userProfile.name}! How can I help you with your career journey today?` }
        ]);
    }, [userProfile]);
    
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages]);

    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!userInput.trim() || !chat) return;

        const userMessage: ChatMessage = { role: 'user', content: userInput };
        setMessages(prev => [...prev, userMessage]);
        setUserInput('');
        setIsLoading(true);

        try {
            const response = await chat.sendMessage({ message: userInput });
            const modelMessage: ChatMessage = { role: 'model', content: response.text };
            setMessages(prev => [...prev, modelMessage]);
        } catch (error) {
            console.error("Chatbot API error:", error);
            const errorMessage: ChatMessage = { role: 'model', content: "Sorry, I'm having trouble connecting right now. Please try again later." };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <>
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="fixed bottom-6 right-6 bg-brand-accent text-base-100 w-16 h-16 rounded-full shadow-lg flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-base-200 focus:ring-brand-accent transform transition-transform hover:scale-110"
                aria-label="Toggle AI Chatbot"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
            </button>
            
            <div className={`fixed bottom-24 right-6 w-full max-w-md h-[70vh] max-h-[600px] bg-base-200 border border-base-300 rounded-2xl shadow-2xl flex flex-col transition-all duration-300 ease-in-out ${isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10 pointer-events-none'}`}>
                <div className="flex items-center justify-between p-4 border-b border-base-300">
                    <h3 className="font-bold text-lg">AI Career Advisor</h3>
                    <button onClick={() => setIsOpen(false)} className="text-text-secondary hover:text-text-primary">&times;</button>
                </div>

                <div className="flex-1 p-4 overflow-y-auto space-y-4">
                    {messages.map((msg, index) => (
                        <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-xs md:max-w-sm rounded-xl px-4 py-2 ${msg.role === 'user' ? 'bg-brand-secondary text-white' : 'bg-base-300 text-text-primary'}`}>
                                <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                            </div>
                        </div>
                    ))}
                     {isLoading && (
                        <div className="flex justify-start">
                            <div className="bg-base-300 text-text-primary rounded-xl px-4 py-2">
                                <div className="flex items-center space-x-1">
                                    <span className="w-2 h-2 bg-text-secondary rounded-full animate-pulse delay-75"></span>
                                    <span className="w-2 h-2 bg-text-secondary rounded-full animate-pulse delay-150"></span>
                                    <span className="w-2 h-2 bg-text-secondary rounded-full animate-pulse delay-300"></span>
                                </div>
                            </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>

                <form onSubmit={handleSendMessage} className="p-4 border-t border-base-300">
                    <div className="flex items-center bg-base-300 rounded-lg">
                        <input
                            type="text"
                            value={userInput}
                            onChange={(e) => setUserInput(e.target.value)}
                            placeholder="Ask me anything..."
                            className="w-full bg-transparent px-4 py-2 focus:outline-none"
                            disabled={isLoading}
                        />
                        <button type="submit" disabled={isLoading || !userInput.trim()} className="p-2 text-brand-secondary disabled:text-text-secondary hover:text-brand-accent disabled:hover:text-text-secondary transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
                        </button>
                    </div>
                </form>
            </div>
        </>
    );
};

export default Chatbot;