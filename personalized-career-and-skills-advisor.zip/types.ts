export interface UserProfile {
  name: string;
  education: string;
  skills: string[];
  interests: string[];
  photo?: string;
  dob?: string;
  linkedin?: string;
  email?: string;
  phone?: string;
  github?: string;
  coins: number;
  dailyStreak: number;
  lastQuizDate: string; // YYYY-MM-DD
  roadmapDurations?: { [careerTitle: string]: string; };
  resumeUrl?: string;
  theme?: 'light' | 'dark' | 'default';
}

export interface CareerPath {
  title: string;
  description: string;
  requiredSkills: string[];
  matchScore: number;
}

export interface SkillRoadmapStage {
  stageName: string;
  skillsToLearn: string[];
  resources: { name: string; url: string; }[];
  projectIdeas: string[];
  estimatedTime?: string;
}

export interface SkillRoadmap {
  careerTitle: string;
  stages: SkillRoadmapStage[];
}

export interface JobInsightData {
  averageSalary: {
    min: number;
    max: number;
    currency: string;
  };
  demand: 'High' | 'Medium' | 'Low';
  inDemandSkills: {
    skill: string;
    demandScore: number; // A score from 1-100
  }[];
  summary: string;
  futureOutlook: string;
}

export interface GroundingSource {
  web?: {
    uri: string;
    title: string;
  }
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}

export interface JobOpening {
    title: string;
    company: string;
    location: string;
    description: string;
    url: string;
    matchScore: number;
}

export type QuizDifficulty = 'Easy' | 'Medium' | 'Hard';

export interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswerIndex: number;
}