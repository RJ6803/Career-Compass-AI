import { GoogleGenAI, Type } from "@google/genai";
import { UserProfile, CareerPath, SkillRoadmap, JobInsightData, GroundingSource, JobOpening, QuizQuestion, QuizDifficulty } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Helper function to extract and parse JSON from the model's raw text response
const parseJsonResponse = <T>(text: string): T => {
    // Find the start and end of the JSON content, accommodating markdown code blocks
    const startIndex = text.indexOf('{');
    const lastIndex = text.lastIndexOf('}');
    const startArrayIndex = text.indexOf('[');
    const lastArrayIndex = text.lastIndexOf(']');
    
    let jsonString;

    // Determine if it's an array or object and extract the string
    if (startArrayIndex !== -1 && lastArrayIndex !== -1 && (startIndex === -1 || startArrayIndex < startIndex)) {
      jsonString = text.substring(startArrayIndex, lastArrayIndex + 1);
    } else if (startIndex !== -1 && lastIndex !== -1) {
      jsonString = text.substring(startIndex, lastIndex + 1);
    } else {
      console.error("No JSON found in response: ", text);
      throw new Error("No valid JSON object or array found in the response.");
    }

    try {
        return JSON.parse(jsonString) as T;
    } catch (error) {
        console.error("Failed to parse JSON response:", jsonString, error);
        throw new Error("Received an invalid JSON response from the AI.");
    }
};

const careerPathSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      title: { type: Type.STRING, description: "The title of the career path." },
      description: { type: Type.STRING, description: "A brief description of the career path." },
      requiredSkills: {
        type: Type.ARRAY,
        items: { type: Type.STRING },
        description: "A list of key skills required for this career."
      },
      matchScore: {
        type: Type.NUMBER,
        description: "A score from 1 to 100 indicating how well this career matches the user's profile."
      }
    },
    required: ["title", "description", "requiredSkills", "matchScore"]
  }
};

const skillRoadmapSchema = {
  type: Type.OBJECT,
  properties: {
    careerTitle: { type: Type.STRING },
    stages: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          stageName: { type: Type.STRING, description: "e.g., Foundational, Intermediate, Advanced" },
          skillsToLearn: { type: Type.ARRAY, items: { type: Type.STRING } },
          resources: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                url: { type: Type.STRING }
              },
              required: ["name", "url"]
            }
          },
          projectIdeas: { type: Type.ARRAY, items: { type: Type.STRING } },
          estimatedTime: { type: Type.STRING, description: "An estimated time to complete this stage, e.g., '2 Weeks' or '1 Month'." }
        },
        required: ["stageName", "skillsToLearn", "resources", "projectIdeas"]
      }
    }
  },
  required: ["careerTitle", "stages"]
};

const quizQuestionSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            question: { type: Type.STRING, description: "The quiz question." },
            options: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "An array of 4 potential answers."
            },
            correctAnswerIndex: {
                type: Type.NUMBER,
                description: "The 0-based index of the correct answer in the options array."
            }
        },
        required: ["question", "options", "correctAnswerIndex"]
    }
};

export const getCareerRecommendations = async (profile: UserProfile): Promise<CareerPath[]> => {
  const prompt = `
    Analyze the following user profile and recommend 3 personalized career paths.
    - User Name: ${profile.name}
    - Education: ${profile.education}
    - Current Skills: ${profile.skills.length > 0 ? profile.skills.join(', ') : 'None specified. The user is a beginner.'}
    - Interests: ${profile.interests.join(', ')}

    For each career path, provide a title, a short description, key required skills, and a match score (1-100) based on their profile.
    Ensure the recommendations are future-ready and align with the user's inputs. If the user has no skills, base the recommendations and match score heavily on their interests and education.
    When skills are updated, the match score should reflect this progress.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: careerPathSchema,
    },
  });
  
  const jsonResponse = JSON.parse(response.text);
  return jsonResponse as CareerPath[];
};

export const getSkillRoadmap = async (careerPath: CareerPath, duration: string): Promise<SkillRoadmap> => {
    const prompt = `
        Create a detailed, step-by-step skill-building roadmap for a user who wants to become a "${careerPath.title}".
        The user wants to complete this roadmap with a ${duration} timeline.
        The roadmap should be broken down into logical stages (e.g., 'Foundation', 'Intermediate', 'Advanced/Specialization').
        For each stage, provide:
        1. A comprehensive list of specific skills to learn for this career path.
        2. A list of recommended online resources (like Coursera, freeCodeCamp, official documentation) with names and URLs for each skill.
        3. A list of practical project ideas to build a portfolio and apply the learned skills.
        4. An "estimatedTime" for completing the stage that aligns with the user's ${duration} goal (e.g., "2 Weeks", "1 Month").
        Assume the user might be a beginner, so start with the fundamentals. Do not tailor the list based on any pre-existing skills; provide the complete roadmap.
    `;
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: skillRoadmapSchema,
        },
    });

    const jsonResponse = JSON.parse(response.text);
    return jsonResponse as SkillRoadmap;
};

export const getJobMarketInsights = async (careerTitle: string, country: string): Promise<{ insights: JobInsightData, sources: GroundingSource[] }> => {
    const prompt = `
        Provide real-time job market insights for the career path: "${careerTitle}" in ${country}.
        Your response MUST be a single, valid JSON object. Do not include any text before or after the JSON.
        The JSON object should conform to this TypeScript interface:
        interface JobInsightData {
          averageSalary: { min: number; max: number; currency: string; }; // Use USD for USA, INR for India
          demand: 'High' | 'Medium' | 'Low';
          inDemandSkills: { skill: string; demandScore: number; }[];
          summary: string;
          futureOutlook: string;
        }
        Find the top 5 most in-demand technical and soft skills.
    `;
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            tools: [{ googleSearch: {} }],
        },
    });
    
    const insights = parseJsonResponse<JobInsightData>(response.text);
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks as GroundingSource[] || [];
    
    return { insights, sources };
};

export const getJobOpenings = async (careerTitle: string, userProfile: UserProfile, country: string, jobType: string): Promise<{ openings: JobOpening[], sources: GroundingSource[] }> => {
    const prompt = `
        Find 5 recent, ${jobType} job openings in ${country} for a "${careerTitle}".
        The user's skills are: ${userProfile.skills.join(', ')}.
        Your response MUST be a single, valid JSON array. Do not include any text before or after the JSON.
        Each object in the array should conform to this TypeScript interface:
        interface JobOpening {
            title: string;
            company: string;
            location: string;
            description: string;
            url: string;
            matchScore: number;
        }
        The matchScore (1-100) should be based on how well the user's skills align with a typical ${jobType} role for this career.
    `;
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            tools: [{ googleSearch: {} }],
        },
    });
    
    const openings = parseJsonResponse<JobOpening[]>(response.text);
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks as GroundingSource[] || [];

    return { openings, sources };
};

export const getQuizForSkill = async (skill: string, difficulty: QuizDifficulty, numQuestions: number): Promise<QuizQuestion[]> => {
    const prompt = `
        Generate a ${numQuestions}-question multiple-choice quiz for an '${difficulty}' level learner on the topic of "${skill}".
        For each question, provide:
        1. A clear question text.
        2. An array of 4 options. One should be correct, and the others should be plausible distractors.
        3. The 0-based index of the correct answer in the options array.
        The questions should test practical understanding, not just definitions, and the difficulty should match the requested level.
    `;
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: quizQuestionSchema,
        },
    });

    const jsonResponse = JSON.parse(response.text);
    return jsonResponse as QuizQuestion[];
};