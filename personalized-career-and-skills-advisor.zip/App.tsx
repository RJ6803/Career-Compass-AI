import React, { useState, useEffect, useCallback } from 'react';
import { UserProfile, CareerPath } from './types';
import ProfileSetup from './components/ProfileSetup';
import MainLayout from './components/MainLayout';
import { getCareerRecommendations } from './services/geminiService';
import { LoadingSpinner } from './components/LoadingSpinner';
import LoginView from './components/LoginView';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<{ id: string; name: string } | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [careerPaths, setCareerPaths] = useState<CareerPath[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true); // Start true to check auth
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Apply theme on initial load and when it changes
    if (!userProfile?.theme) return;

    const root = window.document.documentElement;
    const isSystemDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;

    if (userProfile.theme === 'light') {
        root.classList.add('light');
    } else if (userProfile.theme === 'dark') {
        root.classList.remove('light');
    } else { // 'default'
        if (isSystemDark) {
            root.classList.remove('light');
        } else {
            root.classList.add('light');
        }
    }
  }, [userProfile?.theme]);

  // Add listener for system theme changes if user has selected 'default'
  useEffect(() => {
      if (userProfile?.theme !== 'default') return;

      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      
      const handleChange = (e: MediaQueryListEvent) => {
          const root = window.document.documentElement;
          if (e.matches) {
              root.classList.remove('light');
          } else {
              root.classList.add('light');
          }
      };
      
      mediaQuery.addEventListener('change', handleChange);
      return () => mediaQuery.removeEventListener('change', handleChange);
  }, [userProfile?.theme]);

  const handleProfileSubmit = useCallback(async (profile: UserProfile) => {
    // This function now exclusively handles generating NEW recommendations.
    const userId = localStorage.getItem('careerCompassUserId');
    if (!userId) return;
    
    setIsLoading(true);
    setError(null);
    try {
        const recommendations = await getCareerRecommendations(profile);
        setCareerPaths(recommendations);
        setUserProfile(profile);
        
        // Save the profile AND the newly generated career paths to local storage
        localStorage.setItem(`careerCompassProfile_${userId}`, JSON.stringify(profile));
        localStorage.setItem(`careerCompassPaths_${userId}`, JSON.stringify(recommendations));
    } catch (err) {
        console.error("Failed to get career recommendations:", err);
        setError("Sorry, we couldn't generate career paths. Please try again.");
    } finally {
        setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    // Check for a logged-in user session on initial load
    const storedUserId = localStorage.getItem('careerCompassUserId');
    if (storedUserId) {
      const storedUser = JSON.parse(localStorage.getItem(`careerCompassUser_${storedUserId}`) || 'null');
      const storedProfile = JSON.parse(localStorage.getItem(`careerCompassProfile_${storedUserId}`) || 'null');
      
      if (storedUser && storedProfile) {
        setCurrentUser(storedUser);
        setUserProfile(storedProfile);
        
        const storedPaths = JSON.parse(localStorage.getItem(`careerCompassPaths_${storedUserId}`) || 'null');
        if (storedPaths) {
          // If paths exist, load them
          setCareerPaths(storedPaths);
        } else {
          // Edge case: if profile exists but paths don't, regenerate them.
          handleProfileSubmit(storedProfile);
        }
      }
    }
    setIsLoading(false);
  }, [handleProfileSubmit]);

  const handleLogin = (user: { id: string; name: string; }) => {
    localStorage.setItem('careerCompassUserId', user.id);
    localStorage.setItem(`careerCompassUser_${user.id}`, JSON.stringify(user));
    setCurrentUser(user);
    
    // After logging in, check if a profile and paths already exist for this user
    const storedProfile = JSON.parse(localStorage.getItem(`careerCompassProfile_${user.id}`) || 'null');
    if (storedProfile) {
      setUserProfile(storedProfile);
      const storedPaths = JSON.parse(localStorage.getItem(`careerCompassPaths_${user.id}`) || 'null');
      if (storedPaths) {
        // Load existing career paths instead of regenerating
        setCareerPaths(storedPaths);
      } else {
        // Data inconsistency: profile exists but paths don't. Regenerate.
        handleProfileSubmit(storedProfile);
      }
    }
    // If no profile, the app will transition to the ProfileSetup view automatically
  };

  const handleLogout = () => {
    // Only clear the session ID to log the user out.
    // The user's profile and paths remain in local storage for their next session.
    localStorage.removeItem('careerCompassUserId');

    // Reset component state to transition to the login view
    setCurrentUser(null);
    setUserProfile(null);
    setCareerPaths([]);
  };

  const handleResetProfile = () => {
    if (!currentUser) return;

    // Before clearing state, iterate through existing career paths to clear their cached roadmaps.
    const durations = ['1-month', '3-months', '6-months'];
    careerPaths.forEach(path => {
        durations.forEach(duration => {
            const storageKey = `careerCompassRoadmap_${currentUser.id}_${path.title}_${duration}`;
            localStorage.removeItem(storageKey);
        });
    });

    // Remove the main profile and path data from local storage
    localStorage.removeItem(`careerCompassProfile_${currentUser.id}`);
    localStorage.removeItem(`careerCompassPaths_${currentUser.id}`);
    
    // Clear state to trigger UI update to ProfileSetup view
    setUserProfile(null);
    setCareerPaths([]);
  };

  const handleUpdateProfile = (updatedProfile: UserProfile) => {
    if (!currentUser) return;
    setUserProfile(updatedProfile);
    localStorage.setItem(`careerCompassProfile_${currentUser.id}`, JSON.stringify(updatedProfile));
    // Note: This does NOT regenerate career paths. That's a separate action via "Refresh".
  };
  
  const refreshRecommendations = () => {
    if (userProfile) {
      handleProfileSubmit(userProfile);
    }
  };
  
  // Initial loading state while checking auth
  if (isLoading && !userProfile) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-base-100 text-text-primary p-4">
        <LoadingSpinner />
      </div>
    );
  }

  // No user logged in, show Login page
  if (!currentUser) {
    return <LoginView onLogin={handleLogin} />;
  }
  
  // User is logged in but has no profile, show Profile Setup
  if (!userProfile) {
    return <ProfileSetup onSubmit={(profile) => handleProfileSubmit(profile)} error={error} initialName={currentUser.name} />;
  }

  // User is logged in and has a profile, show the main app
  return (
    <MainLayout 
      userProfile={userProfile} 
      careerPaths={careerPaths} 
      onLogout={handleLogout} 
      onResetProfile={handleResetProfile}
      onUpdateProfile={handleUpdateProfile}
      onRefreshRecommendations={refreshRecommendations}
      isUpdatingRecommendations={isLoading}
      userId={currentUser.id}
    />
  );
};

export default App;